// // import React from 'react';
// // import { useState} from 'react';

// // import { Container, Row, Col, Form, Button } from 'react-bootstrap';
// // import axios from "axios";
// // import swal from "sweetalert";

// // import './App.css';
// // const LoginForm = () => {

// //   const [email, setEmail] = useState("");
// //   const [password, setPassword] = useState("");

// //   const handleSubmit = async (event) => {
// //     event.preventDefault();

// //     const loginData = {
// //       email: email,
// //       password: password,
// //     };
// //     console.log(loginData);
// //     try {
// //       const response = await axios.post("/api/login", loginData);

// //       const { token } = response.data;

// //       console.log(response.data);

// //       localStorage.setItem("token", token);
// //       setEmail("");
// //       setPassword("");

// //       axios
// //         .get("/api/users", {
// //           headers: {
// //             Authorization: `Bearer ${token}`,
// //           },
// //         })
// //         .then((response) => {
// //           const data = response.data.data;
// //           swal("Success", "Successfully logged in", "success");
// //           localStorage.setItem("user_id", data._id);
// //           localStorage.setItem("user_email", data.email);
// //           localStorage.setItem("user_role", data.role);
// //           // console.log(data.email);

// //           setTimeout(() => {
// //             window.location.href = "/dashboard";
// //           }, 2000);
// //         });
// //     } catch (error) {
// //       swal(error.response.data.message);
// //     }
// //   };

  
// //     return (

// //         <div className="container">          
// //         <div className="screen">
        
// //           <div className="screen__content">
// //             <form className="login">
// //             <h1 class="form__heading">Admin</h1><br/>

// //               <div className="login__field">
// //                 <i className="login__icon fas fa-user"></i>
// //                 <input
// //                   type="text"
// //                   className="login__input"
// //                   placeholder="Enter your email..."
// //                 />
// //               </div>
// //               <div className="login__field">
// //                 <i className="login__icon fas fa-lock"></i>
// //                 <input
// //                   type="password"
// //                   className="login__input"
// //                   placeholder="Enter your password..."
// //                 />
// //               </div>
// //               <button className="button login__submit">
// //                 <span className="button__text">Login</span>
// //                 <i className="button__icon fas fa-chevron-right"></i>
// //               </button>
// //             </form>
          
// //           </div>
// //           <div className="screen__background">
// //             <span className="screen__background__shape screen__background__shape4"></span>
// //             <span className="screen__background__shape screen__background__shape3"></span>
// //             <span className="screen__background__shape screen__background__shape2"></span>
// //             <span className="screen__background__shape screen__background__shape1"></span>
// //           </div>
// //         </div>
// //       </div>
// //     );
// //   };
  
// //   export default LoginForm;
  

// import React, { useState } from 'react';

// import axios from 'axios';

// function LoginForm() {
//   const [email, setEmail] = useState('');
//   const [password, setPassword] = useState('');

//   const handleLogin = async (e) => {
//     e.preventDefault();

//     try {
//       const response = await axios.post('/api/login', {
//         email,
//         password,
//       });

//       // Assuming your backend returns a success message or token upon successful login
//       if (response.data.success) {
//         console.log('Login successful!', response.data);
//         // You can store the token or perform any other actions after successful login
//       } else {
//         console.error('Login failed. Please check your credentials.');
//       }
//     } catch (error) {
//       console.error('Error occurred during login:', error);
//     }
//   };


  
//   return (
//     <div className="container">          
//       <div className="screen">
//         <div className="screen__content">
//           <form className="login" onSubmit={handleLogin}>
//             <h1 className="form__heading">Admin</h1><br/>
//             <div className="login__field">
//               <i className="login__icon fas fa-user"></i>
//               <input
//                 type="text"
//                 className="login__input"
//                 placeholder="Enter your email..."
//                 value={email}
//                 onChange={(e) => setEmail(e.target.value)}
//               />
//             </div>
//             <div className="login__field">
//               <i className="login__icon fas fa-lock"></i>
//               <input
//                 type="password"
//                 className="login__input"
//                 placeholder="Enter your password..."
//                 value={password}
//                 onChange={(e) => setPassword(e.target.value)}
//               />
//             </div>
//             <button type="submit" className="button login__submit">
//               <span className="button__text">Login</span>
//               <i className="button__icon fas fa-chevron-right"></i>
//             </button>
//           </form>
//         </div>
//         <div className="screen__background">
//           <span className="screen__background__shape screen__background__shape4"></span>
//           <span className="screen__background__shape screen__background__shape3"></span>
//           <span className="screen__background__shape screen__background__shape2"></span>
//           <span className="screen__background__shape screen__background__shape1"></span>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default LoginForm;



import React, { useState } from "react";

import { makeStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import axios from "axios";
import swal from "sweetalert";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    minHeight: "100vh",
    padding: "0 20px",
    boxSizing: "border-box",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    width: "100%",
    maxWidth: "400px",
  },
  textField: {
    width: "100%",
    marginBottom: theme.spacing(2),
  },
  button: {
    width: "23%",
    fontSize: "0.8rem",
    marginTop: theme.spacing(2),
  },
}));

function LoginForm() {
  const classes = useStyles();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = async (event) => {
    event.preventDefault();

    const loginData = {
      email: email,
      password: password,
    };
    console.log(loginData);
    try {
      const response = await axios.post("/api/login", loginData);

      const { token } = response.data;

      console.log(response.data);

      localStorage.setItem("token", token);
      setEmail("");
      setPassword("");

      axios
        .get("/api/users", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        })
        .then((response) => {
          const data = response.data.data;
          console.log(data);
          swal("Success", "Successfully logged in", "success");
          localStorage.setItem("user_id", data._id);
          localStorage.setItem("user_email", data.email);
          localStorage.setItem("user_role", data.role);
          // console.log(data.email);

          setTimeout(() => {
            window.location.href = "/dashboard";
          }, 2000);
        });
    } catch (error) {
      swal(error.response.data.message);
    }
  };

  return (
    <div className={classes.root}>
      <form className={classes.form} onSubmit={handleSubmit}>
        <TextField
          id="email"
          label="Email"
          variant="outlined"
          value={email}
          onChange={(event) => setEmail(event.target.value)}
          className={classes.textField}
        />
        <br />
        <TextField
          id="password"
          label="Password"
          variant="outlined"
          type="password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          className={classes.textField}
        />
        <br />
        <Button
          type="submit"
          variant="contained"
          color="primary"
          className={classes.button}
        >
          Login
        </Button>
      </form>
    </div>
  );
}

export default LoginForm;
