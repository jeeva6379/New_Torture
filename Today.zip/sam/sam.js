const express = require('express');
const axios = require('axios');
const cheerio = require('cheerio');

const app = express();

async function performGoogleSearch(query) {
  try {
    const url = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
    const response = await axios.get(url);

    const searchResults = [];
    const $ = cheerio.load(response.data);

    // Extracting search results from the page
    $('div.g').each((index, element) => {
      const title = $(element).find('h3').text();
      const link = $(element).find('a').attr('href');
      const description = $(element).find('div.s').text();
      searchResults.push({ title, link, description });
    });

    return searchResults;
  } catch (error) {
    console.error('Error performing Google search:', error);
    throw error;
  }
}

// Endpoint to perform the Google search
app.get('/search', async (req, res) => {
  const searchQuery = req.query.q || 'https://www.youtube.com/results?search_query=input+as+check+in+google+in+node+js'; // Default search query if not provided in the query parameter
  try {
    const results = await performGoogleSearch(searchQuery);
    console.log(results);
    res.json({ results });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

const port = 3000; // Replace with your desired port number
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
