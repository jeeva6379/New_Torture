const express = require('express');
const multer = require('multer');
const { PDFDocument } = require('pdf-lib');
const Docxtemplater = require('docxtemplater');
const fs = require('fs');
const path = require('path');

const app = express();
const port = 3000;

// Set up file upload using multer
const upload = multer({ dest: 'uploads/' });

// Example highlighting function
function highlightWords(text, words) {
  words.forEach((word) => {
    const regex = new RegExp(`\\b${word}\\b`, 'gi');
    text = text.replace(regex, `<span style="background-color: yellow;">${word}</span>`);
  });
  return text;
}

// API endpoint to handle file upload
app.post('/upload', upload.single('file'), async (req, res) => {
  try {
    // Read the uploaded file and extract text (assuming it's a Word document)
    const filePath = path.join(__dirname, req.file.path);
    const fileContent = fs.readFileSync(filePath, 'binary');
    const doc = new Docxtemplater();
    doc.loadZip(fileContent);
    const text = doc.getFullText();

    // Highlight specific words in the text
    const wordsToHighlight = ['word1', 'word2', 'word3'];
    const highlightedText = highlightWords(text, wordsToHighlight);

    // Convert the highlighted text to PDF
    const pdfDoc = await PDFDocument.create();
    const page = pdfDoc.addPage();
    page.drawText(highlightedText, { x: 50, y: page.getHeight() - 100 });

    // Save the PDF file
    const pdfPath = path.join(__dirname, 'output.pdf');
    const pdfBytes = await pdfDoc.save();
    fs.writeFileSync(pdfPath, pdfBytes);

    // Respond with the download link to the converted PDF
    res.json({ downloadLink: `/download` });
  } catch (err) {
    res.status(500).json({ error: 'An error occurred while processing the file.' });
  }
});

// API endpoint to download the converted PDF
app.get('/download', (req, res) => {
  const pdfPath = path.join(__dirname, 'output.pdf');
  res.download(pdfPath, 'highlighted_document.pdf', (err) => {
    if (err) {
      res.status(500).json({ error: 'An error occurred while downloading the file.' });
    } else {
      // Clean up the generated files after download
      fs.unlinkSync(pdfPath);
      fs.unlinkSync(path.join(__dirname, req.file.path));
    }
  });
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
