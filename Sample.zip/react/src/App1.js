import React, { useState } from 'react';

import axios from 'axios';

const App1 = () => {
  const [file, setFile] = useState(null);
  const [downloadLink, setDownloadLink] = useState('');

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  const handleUpload = async () => {
    if (!file) {
      alert('Please select a file.');
      return;
    }

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await axios.post('/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      if (response.status === 200) {
        const data = response.data;
        setDownloadLink(data.downloadLink);
      } else {
        alert('Error occurred during file processing.');
      }
    } catch (error) {
      alert('Error occurred during file upload.');
    }
  };

  return (
    <div>
      <h1>Document Highlighter</h1>
      <input type="file" onChange={handleFileChange} />
      <button onClick={handleUpload}>Upload</button>
      {downloadLink && (
        <p>
          <a href={downloadLink} download>
            Download Highlighted PDF
          </a>
        </p>
      )}
    </div>
  );
};

export default App1;
